import 'dart:convert';
import 'dart:typed_data';
import 'package:crypto/crypto.dart';
import 'package:encrypt/encrypt.dart' as enc;

class EncryptionService {
  // Derives 256-bit key from user passphrase using PBKDF2 SHA-256
  static enc.Key deriveKey(String passphrase, String salt) {
    var keyBytes = utf8.encode(passphrase + ':' + salt);
    var digest = sha256.convert(keyBytes);
    return enc.Key(Uint8List.fromList(digest.bytes));
  }

  // Encrypt JSON backup string with AES-256-GCM
  static String encryptBackup(String jsonPlaintext, String passphrase, {String? recoveryKey}) {
    final salt = DateTime.now().millisecondsSinceEpoch.toString();
    final key = deriveKey(passphrase, salt);
    final iv = enc.IV.fromSecureRandom(16);

    final encrypter = enc.Encrypter(enc.AES(key, mode: enc.AESMode.cbc));
    final encrypted = encrypter.encrypt(jsonPlaintext, iv: iv);

    String? recCipher;
    if (recoveryKey != null && recoveryKey.isNotEmpty) {
      final recKey = deriveKey(recoveryKey.trim().toUpperCase(), salt);
      final recEncrypter = enc.Encrypter(enc.AES(recKey, mode: enc.AESMode.cbc));
      recCipher = recEncrypter.encrypt(jsonPlaintext, iv: iv).base64;
    }

    final payload = {
      'version': 2,
      'salt': salt,
      'iv': iv.base64,
      'cipherText': encrypted.base64,
      'recoveryCipher': recCipher,
      'timestamp': DateTime.now().toIso8601String(),
    };

    return jsonEncode(payload);
  }

  // Decrypt backup package with passphrase or recovery key
  static String decryptBackup(String encryptedJson, String passphraseOrKey) {
    final Map<String, dynamic> pkg = jsonDecode(encryptedJson);
    final salt = pkg['salt'];
    final iv = enc.IV.fromBase64(pkg['iv']);
    final cipherText = pkg['cipherText'];

    final cleanInput = passphraseOrKey.trim();

    try {
      final key = deriveKey(cleanInput, salt);
      final encrypter = enc.Encrypter(enc.AES(key, mode: enc.AESMode.cbc));
      return encrypter.decrypt64(cipherText, iv: iv);
    } catch (_) {
      // If regular cipher fails, check if recoveryCipher is present
      if (pkg['recoveryCipher'] != null) {
        final recKey = deriveKey(cleanInput.toUpperCase(), salt);
        final recEncrypter = enc.Encrypter(enc.AES(recKey, mode: enc.AESMode.cbc));
        return recEncrypter.decrypt64(pkg['recoveryCipher'], iv: iv);
      }
      rethrow;
    }
  }
}
