# Electro Hisab - Electronics Shop Android App

Complete offline-first POS, inventory management, customer/supplier khata ledger, and thermal receipt billing system.

## 📱 LG V60 Android Phone Workflow (Phone-Only, Zero Cost)

If you only have an **LG V60 Android phone** and no computer:

### Option 1: Instant Standalone Offline App (Recommended)
1. Open this application in Google Chrome on your LG V60.
2. Tap the Chrome menu (**3 vertical dots** in the top right).
3. Tap **Install app** or **Add to Home screen**.
4. "Electro Hisab" installs directly as an independent app icon in your phone's app launcher!
5. It runs 100% offline with zero cloud server, using your LG V60's local hardware storage and hardware-accelerated 60Hz display.

### Option 2: Build Native Android APK via Free GitHub Actions (No Computer Needed)
1. Download the `ElectroHisab_Android_Flutter_Project.zip` archive to your phone.
2. Create a free account at [github.com](https://github.com).
3. Create a new private repository called `electro-hisab`.
4. Upload the unzipped files into your repository.
5. GitHub will automatically detect `.github/workflows/build_apk.yml` and compile the native `app-release.apk` on free cloud runners!
6. Open the **Actions** tab on your phone, download the compiled `app-release.apk`, and tap to install on your LG V60.

---

## 💻 Building in Android Studio (Computer Workflow)

If you have access to a computer:
1. Install [Flutter SDK 3.19+](https://docs.flutter.dev/get-started/install).
2. Open the project in Android Studio.
3. Run `flutter pub get` in terminal.
4. Run `flutter test` to execute automated unit tests.
5. Build the APK:
   ```bash
   flutter build apk --release
   ```
6. The resulting file will be at:
   `build/app/outputs/flutter-apk/app-release.apk`
