import 'package:flutter_test/flutter_test.dart';
import 'package:electro_hisab/services/encryption_service.dart';

void main() {
  group('Electro Hisab Business Logic Tests', () {
    test('Gross & Net Profit Calculation', () {
      const double salesRevenue = 150000.0;
      const double costOfGoodsSold = 115000.0;
      const double operatingExpenses = 18000.0;

      final double grossProfit = salesRevenue - costOfGoodsSold;
      final double netProfit = grossProfit - operatingExpenses;

      expect(grossProfit, 35000.0);
      expect(netProfit, 17000.0);
      expect((grossProfit / salesRevenue) * 100, closeTo(23.33, 0.01));
    });

    test('Inventory Stock Adjustment & Non-Negative Prevention', () {
      int initialStock = 10;
      int soldQuantity = 3;
      int purchasedQuantity = 5;

      int afterSale = initialStock - soldQuantity;
      expect(afterSale, 7);

      int afterRestock = afterSale + purchasedQuantity;
      expect(afterRestock, 12);

      // Attempting to sell more than available
      bool prevented = false;
      int attemptOversell = 15;
      if (afterRestock - attemptOversell < 0) {
        prevented = true;
      }
      expect(prevented, true);
    });

    test('Customer Khata Debit/Credit Balance Verification', () {
      double currentBalance = 0.0;
      double creditSale = 45000.0; // Debit
      double paymentReceived = 20000.0; // Credit

      currentBalance += creditSale;
      expect(currentBalance, 45000.0);

      currentBalance -= paymentReceived;
      expect(currentBalance, 25000.0);
    });

    test('AES-256 Encryption & Recovery Key Decryption Round-Trip', () {
      const sampleDatabaseJson = '{"shop":"Electro Hisab","records":42}';
      const password = 'mySecurePassword123';
      const recoveryKey = 'EH-8K4P-9N2X-7T1Q';

      final encrypted = EncryptionService.encryptBackup(
        sampleDatabaseJson,
        password,
        recoveryKey: recoveryKey,
      );

      // Decrypt using password
      final decrypted1 = EncryptionService.decryptBackup(encrypted, password);
      expect(decrypted1, sampleDatabaseJson);

      // Decrypt using recovery key
      final decrypted2 = EncryptionService.decryptBackup(encrypted, recoveryKey);
      expect(decrypted2, sampleDatabaseJson);
    });
  });
}
