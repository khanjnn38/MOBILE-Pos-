# Third-Party Open Source Dependencies & Licenses

Electro Hisab uses only permissive open-source packages without proprietary cloud lock-in:

| Package | Purpose | License |
| :--- | :--- | :--- |
| **sqflite** | SQLite database driver for Android | MIT License |
| **path** | File system path operations | BSD-3-Clause |
| **path_provider** | App-private storage locator | BSD-3-Clause |
| **encrypt** | AES-256 symmetric cipher | MIT License |
| **crypto** | SHA-256 and PBKDF2 hashing | BSD-3-Clause |
| **intl** | Currency and date formatting | BSD-3-Clause |
| **pdf** | PDF generation engine | Apache 2.0 |
| **printing** | Thermal and ESC/POS printer driver | Apache 2.0 |
| **share_plus** | Android native share intent | BSD-3-Clause |

No proprietary services or external analytics are included.
